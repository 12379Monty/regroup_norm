########################################################################
##
##	Internal function, used by AnalyzeTilingCelFiles.
##
##	Given cel-file X/ Y positions and a raw vector of CEL intensities,
##	returns preoperly sorted RAW intensity values.
##
#######################################################################
GetRawExpression <- function(X, Y, INT, ROWSIZE, COLSIZE) {
	X <- as.integer(X)
	Y <- as.integer(Y)
	ROWSIZE <- as.integer(ROWSIZE)
	COLSIZE <- as.integer(COLSIZE)

	INT <- as.real(INT)
	dim(X) <- c(NROW(X), NCOL(X))
	dim(Y) <- c(NROW(Y), NCOL(Y))
	dim(INT) <- c(NROW(INT), NCOL(INT))
	SORTED_INT <- .Call("ExtractRAWIntensity", X, Y, INT, COLSIZE, PACKAGE = "AffyTiling")
	return(SORTED_INT)
}

################################################################################
##
##	Extracts intensity data from a group of CEL files and returns annotated 
##	intensities using information from a BPMAP file. Options can be set to 
##	limit the analysis to certain genomic features or regions of interest,
##	thus requiring less memory and computing time.
##
##	By default, preforms background correction, qualtile normalization, and log2 
##	transform.  This can be disabled by the user.
##
################################################################################
AnalyzeTilingCelFiles <- function(CEL_filenames, 
					BPMAP_filename, 
					outfilename=NULL, 

					iID=NULL, iCHR=NULL, iSTART=NULL, iEND=NULL, 
					makeUniqueID=TRUE, readOnlyNCBI=TRUE, readProbeSeq=FALSE,
					IgnoreBpmapCelPlatformMismatch=FALSE, 

					ReturnRawIntensities=FALSE) {
	# Get CEL header information... Check that BPMAP and first CEL file are of the same chiptype...
	Head <- readCelHeader(CEL_filenames[1])
	N_CEL_ROWS <- Head$rows
	N_CEL_COLS <- Head$cols
	CEL_TYPE   <- Head$chiptype
	if(NROW(grep(CEL_TYPE, BPMAP_filename)) == 0) {
		print("WARNING: The input CEL file suggests a different platform than the PBMAP file.")
		print(paste("CEL platform: '", CEL_TYPE, "'", sep=""))
		print(paste("BPMAP filename: '", BPMAP_filename, "'", sep=""))

		if(!IgnoreBpmapCelPlatformMismatch) {
			stop("ERROR!! Wrong BPMAP file?!  Exiting!")
		}
	}

	##### BPMAP information
	print("Importing BPMAP file.")
	MATRIX <- parseBPMAP(BPMAP_filename, 
				iID=iID, iCHR=iCHR, iSTART=iSTART, iEND=iEND, 
				makeUniqueID=makeUniqueID, 
				readOnlyNCBI=readOnlyNCBI, 
				readProbeSeq=readProbeSeq)
	
	# Read CEL files & extract intensities
	RAW_I <- NULL
	print("Reading CEL Files & Extracting Intensities.")
	for(i in 1:NROW(CEL_filenames)) {
		if( readCelHeader(CEL_filenames[i])$chiptype != CEL_TYPE ) {
			stop(paste("ERROR!! The input CEL file '", CEL_filenames[i], 
				"' has a different chiptype.  Exiting!", sep=""))
		}

		CEL <- readCel(CEL_filenames[i], readOutliers = FALSE, readMasked = FALSE)

## Background correct CEL[["intensities"]] -- Better to calculate background based on ENTIRE chip?! ##
		if(!ReturnRawIntensities) {
			dim(CEL[["intensities"]]) <- c(NROW(CEL[["intensities"]]), NCOL(CEL[["intensities"]]))
#			CEL[["intensities"]] <- rma.background.correct(CEL[["intensities"]], copy=FALSE) # if new R.
			CEL[["intensities"]] <- apply(CEL[["intensities"]],2,bg.adjust) # if old R.
		}

		RAW_I <- cbind(RAW_I, GetRawExpression(MATRIX[["PMX"]], MATRIX[["PMY"]], 
			CEL[["intensities"]], N_CEL_ROWS, N_CEL_COLS))
	}

	# Preform RMA-like normalization, if called for.
	if(!ReturnRawIntensities) {
		# Background correct, Quantile normalize, and Log2-transform the data.
		# Affy background correction changed in new version.

# Background correcting here is after we throw away some values on the CHIP.  BGCorrect based on entire array.
#		print("Background correcting.")
#		RAW_I <- apply(RAW_I,2,bg.adjust) # if old R.
#		RAW_I <- rma.background.correct(RAW_I, copy=FALSE) # if new R.
	
		print("Quantile normalizing/ log(2) transform.")
		RAW_I <- normalize.quantiles(RAW_I, copy=FALSE)
		RAW_I <- log(RAW_I, 2)
	}

	# Format & write the data to a file... cbind quite slow!
	print("Finalizing data.")
	colnames(RAW_I) <- CEL_filenames
	if(makeUniqueID & readProbeSeq) {
		ALL_DATA <- cbind(MATRIX[["UniqueID"]], MATRIX[["Start"]], MATRIX[["CHR"]], MATRIX[["SEQ"]], RAW_I)
	}
	else if(makeUniqueID) {
		ALL_DATA <- cbind(UniqueID= MATRIX[["UniqueID"]], START= MATRIX[["Start"]], CHR= MATRIX[["CHR"]], RAW_I)
	}
	else if(readProbeSeq) {
		ALL_DATA <- cbind(START= MATRIX[["Start"]], CHR= MATRIX[["CHR"]], SEQ= MATRIX[["SEQ"]], RAW_I)
	}
	else {
		ALL_DATA <- cbind(START= MATRIX[["Start"]], CHR= MATRIX[["CHR"]], RAW_I)
	}

	if(!is.null(outfilename)) {
		write.table(ALL_DATA, outfilename, row.names=FALSE, sep="\t")
	}

	return(ALL_DATA)
}
