########################################################################
##
##	Returns the nearest gene for each probe.
##
##	How does affy overload, and take wither a matrix or separate vectors??
##
########################################################################
AssociateWithGenes <- function(kgID, kgCHR, kgSTR, kgSTART, kgEND, pID, pCHR, pMID, D=NULL) {
	if(!is.null(D)) {
		D <- as.integer(D)
	}
	C <- unique(kgCHR)
	GENES <- NULL
	for(i in 1:NROW(C)) {
		# Which KG?  prb?
		indxKG  <- which(kgCHR == C[i])
		indxPrb <- which(pCHR  == C[i])

		if((NROW(indxKG) >0) & (NROW(indxPrb) >0)) {
			Genes <- NULL

			# Filter/ Type coersions.
			KGID <- as.character(kgID[indxKG])
			KGSTR <- as.character(kgSTR[indxKG])
			KGSTART <- as.integer(kgSTART[indxKG])
			KGEND <- as.integer(kgEND[indxKG])
			PROBEID <- as.character(pID[indxPrb])
			PROBEMID <- as.integer(pMID[indxPrb])
			# Set dimensions.
			dim(KGID) <- c(NROW(KGID), NCOL(KGID))
			dim(KGSTR) <- c(NROW(KGSTR), NCOL(KGSTR))
			dim(KGSTART) <- c(NROW(KGSTART), NCOL(KGSTART))
			dim(KGEND) <- c(NROW(KGEND), NCOL(KGEND))
			dim(PROBEID) <- c(NROW(PROBEID), NCOL(PROBEID))
			dim(PROBEMID) <- c(NROW(PROBEMID), NCOL(PROBEMID))

			# Load & run C function.
			if(is.null(D)) {
				Genes <- .Call("AssociateRegionWithGenes", KGID, KGSTR, KGSTART, KGEND, 
									PROBEMID,  PACKAGE = "AffyTiling")
				GENES <- rbind(GENES, cbind(PROBEID, Genes[[1]], Genes[[2]]))
			}
			else {
				Genes <- .Call("AssociateRegionWithGenesDI", KGID, KGSTR, KGSTART, KGEND, 
									PROBEID, PROBEMID, D, PACKAGE = "AffyTiling")
				GENES <- rbind(GENES, cbind(Genes[[1]], Genes[[2]], Genes[[3]]))
			}

		}
	}

	#Create & return values.
	if(!is.null(GENES)) {
		colnames(GENES) <- c("ProbeID", "GeneID", "pgDistance")
	}

	return(GENES)
}

