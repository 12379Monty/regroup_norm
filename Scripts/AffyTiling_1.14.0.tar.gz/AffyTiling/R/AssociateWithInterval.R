########################################################################
##
##	FeatureStart and FeatureEnd should be vectors ONLY on the same 
##	chromosome as PROBEStart!!!
##
##	--Probes are assumed to be 25bp.
##	--Calls C function for speed.
##	--Returns index of feature island to which a probe belongs, assuming SAME CHR!
##	--For probes that are not inside a feature, NA is returned.
##
##	TODO: Return feature names/ UniqueID...
##
##	2009-02-06 Updated to allow assocation of features with arbitrary length.
##
########################################################################
AssociateWithInterval <- function(fID, fCHR, fSTART, fEND, pCHR, pSTART, pLENGTH= 25) {

	C <- unique(fCHR)
	F <- rep(NA, NROW(fID))
	if(NROW(pLENGTH) == 1) {
		pLENGTH <- rep(pLENGTH, NROW(pSTART))
	}
	for(i in 1:NROW(C)) {
		# Which KG?  prb?
		indxF   <- which(fCHR == C[i])
		indxPrb <- which(pCHR == C[i])

		if((NROW(indxF) >0) & (NROW(indxPrb) >0)) {
			# Type coersions.
			FeatureStart <- as.integer(fSTART[indxF])
			FeatureEnd <- as.integer(fEND[indxF])
			PROBEStart <- as.integer(pSTART[indxPrb])
			PROBELength <- as.integer(pLENGTH[indxPrb])

			# Set dimensions.
			dim(PROBEStart) <- c(NROW(PROBEStart), NCOL(PROBEStart))
			dim(FeatureStart) <- c(NROW(FeatureStart), NCOL(FeatureStart))
			dim(FeatureEnd) <- c(NROW(FeatureEnd), NCOL(FeatureEnd))
			dim(PROBELength) <- c(NROW(PROBELength), NCOL(PROBELength))
		
			f <- .Call("AssociateRegionWithFeatures", FeatureStart, FeatureEnd, PROBEStart, PROBELength, PACKAGE = "AffyTiling")

			F[indxPrb] <- as.character(fID[indxF][as.vector(f)])
		}
	}

	return(F)
}
 
