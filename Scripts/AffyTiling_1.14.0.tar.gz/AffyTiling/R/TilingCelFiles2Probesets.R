################################################################################
##
##	Extracts intensity data from a group of CEL files.  
##
##	Unlike AnalyzeTilingCelFiles, this function REQUIRES the user to pass 
##	interval information.  Probes in each interval are treated like AffyMetrix
##	probesets during the RMA normalization protocol.  
##
##	If iID is NULL, IDs of the form: "iCHR-iSTART-iEND" and created and returned.
##
################################################################################
TilingCelFiles2Probesets <- function(CEL_filenames, 
					BPMAP_filename, 
					outfilename=NULL, 

					iID=NULL, iCHR, iSTART, iEND, 
					IgnoreBpmapCelPlatformMismatch=FALSE) {

	# Get CEL header information... Check that BPMAP and first CEL file are of the same chiptype...
	Head <- readCelHeader(CEL_filenames[1])
	N_CEL_ROWS <- Head$rows
	N_CEL_COLS <- Head$cols
	CEL_TYPE   <- Head$chiptype
	if(NROW(grep(CEL_TYPE, BPMAP_filename)) == 0) {
		print("WARNING: The input CEL file suggests a different platform than the PBMAP file.")
		print(paste("CEL platform: '", CEL_TYPE, "'", sep=""))
		print(paste("BPMAP filename: '", BPMAP_filename, "'", sep=""))

		if(!IgnoreBpmapCelPlatformMismatch) {
			stop("ERROR!! Wrong BPMAP file?!  Exiting!")
		}
	}

	##### Create probeset IDs.
	if(is.null(iID)) {
		iID <- paste(iCHR, iSTART, iEND, sep="-")
	}

	##### BPMAP information
	print("Importing BPMAP file.")
	MATRIX <- parseBPMAP(BPMAP_filename, 
				iID=iID, iCHR=iCHR, iSTART=iSTART, iEND=iEND, 
				recordIntervalIDs=TRUE,
				makeUniqueID=FALSE, 
				readOnlyNCBI=TRUE, 
				readProbeSeq=FALSE)
	
	#### Read CEL files & extract intensities
	RAW_I <- NULL
	print("Reading CEL Files & Extracting BG Corrected Intensities.")
	for(i in 1:NROW(CEL_filenames)) {
		if( readCelHeader(CEL_filenames[i])$chiptype != CEL_TYPE ) {
			stop(paste("ERROR!! The input CEL file '", CEL_filenames[i], 
				"' has a different chiptype.  Exiting!", sep=""))
		}

		CEL <- readCel(CEL_filenames[i], readOutliers = FALSE, readMasked = FALSE)

		## Background correct CEL[["intensities"]] -- Better to calculate background based on ENTIRE chip?!
		dim(CEL[["intensities"]]) <- c(NROW(CEL[["intensities"]]), NCOL(CEL[["intensities"]]))
		CEL[["intensities"]] <- apply(CEL[["intensities"]],2,bg.adjust) # if old R.

		RAW_I <- cbind(RAW_I, GetRawExpression(MATRIX[["PMX"]], MATRIX[["PMY"]], 
			CEL[["intensities"]], N_CEL_ROWS, N_CEL_COLS))
	}

	#### Preform RMA normalization, including probesets.
	print("Doing RMA correction.")

		  #background correction
		  bg.dens <- function(x){density(x,kernel="epanechnikov",n=2^14)}

		dim(RAW_I)[1] <- NROW(RAW_I)
		dim(RAW_I)[2] <- NCOL(RAW_I)

  	EXPR <- .Call("rma_c_complete", RAW_I, MATRIX[["iID"]], length(unique(MATRIX[["iID"]])), body(bg.dens),new.env(),
 			TRUE,FALSE,1,TRUE,PACKAGE="affy")
#Bottom row is:Norm?,BG Correct?,BGCorrect Type,Verbose.  --> Choose not to background correct, we did it earlier on entire CEL file -- should be more accurate if we are only taking a small piece.

	colnames(EXPR) <- CEL_filenames
##	EXPR <- cbind(unique(MATRIX[["iID"]]), EXPR)

	if(!is.null(outfilename)) {
		write.table(EXPR, outfilename)
	}

	return(EXPR)
}
