################################################################################
##
##	Based loosely on readBPMAP function from the affxparser package.
##
##	parseBPMAP <- function(filename, 
##			iID=NULL,
##			iCHR=NULL, 
##			iSTART=NULL, 
##			iEND=NULL, 
##			recordIntervalIDs = FALSE,
##			makeUniqueID = TRUE,
##			readOnlyNCBI = TRUE, 
##			seqIndices = NULL, 
##			readProbeSeq = TRUE, 
##			verbose = 0)
##
##	8-31-08	Added "recordIntervalIDs" logical -- causes a character vector named, 
##		iID, to be returned that gives the interval to which each probe belongs.
##
################################################################################

parseBPMAP <- function(filename, 
			iID=NULL,
			iCHR=NULL, 
			iSTART=NULL, 
			iEND=NULL, 
			recordIntervalIDs = FALSE,
			makeUniqueID = TRUE,
			readOnlyNCBI = TRUE, 
			seqIndices = NULL, 
			readProbeSeq = TRUE, 
			verbose = 0){
	if(!is.null(iSTART)) {
		iID <- as.character(iID)
		dim(iID)    <- c(NROW(iID),    NCOL(iID))
	}
	else {
		recordIntervalIDs = FALSE
	}
	if( xor(is.null(iID), is.null(iCHR)) 
		| xor(is.null(iCHR), is.null(iSTART)) 
		| xor(is.null(iSTART), is.null(iEND)) ) {
		stop("When limiting analysis to a genomic interval, all interval information is required!")
	}
	if(NROW(filename) == 0) {
		stop("Please specify the location of a .bpmap file.")
	}
	.Call("R_affx_parseBPMAP", filename, 
					as.integer(seqIndices), 
					!is.null(iID), recordIntervalIDs, 
					iID, as.character(iCHR), 
					as.integer(iSTART), as.integer(iEND),

					makeUniqueID, readOnlyNCBI, readProbeSeq,
					as.integer(verbose), 
					PACKAGE = "AffyTiling")
}
