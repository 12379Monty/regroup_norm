/********************************************************************************
 *
 *	Source code written for AffxParser by Charles Danko.
 *
 *	2009-02-06 AssociateRegionWithFeatures updated to allow assocation of features with arbitrary length.
 *	2008-07-07 Updated code to be more readable -- Improved comments + DRY compliance.
 *
 ********************************************************************************/

using namespace std;

extern "C" {

/**************************************************************
*
*	Associates a vector of regions with a table of genes.
*
**************************************************************/
#include <R.h> 
#include <Rdefines.h>
#include <Rmath.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*****************************************************************************************
*
*	Match a probeID to genes.
*
*	Arguments:
*	KG_ID		<- String vector, the ID of known genes.
*	KG_STR		<- String vector, the strand (+/-) of known genes.
*	KG_START	<- Integer vector, the start position (bp) of known genes.
*	KG_END		<- Integer vector, the end position (bp) of known genes.
*	MID		<- Integer vector, the center position (bp) of each probe.
*
*	Return values: a matrix with the following components:
*	gene_id		<- String vector, known gene ID.
*	gene_dist	<- Integer vector, distance between the probe and gene.
*
*	Assumes:
*	All genes and probes are on the same chromosome!!
*	Arguments KG_ID, KG_STR, KG_START, and KG_END have the same length.
*
*	Finally, note that ProbesetIDs are not returned!
*
*****************************************************************************************/
SEXP AssociateRegionWithGenes(SEXP KG_ID, SEXP KG_STR, SEXP KG_Start, SEXP KG_End, /*SEXP pID,*/ SEXP MID) {

	// Reterive passed values.
	int *gSTART = INTEGER(KG_Start);
	int *gEND = INTEGER(KG_End);
	int *pMID = INTEGER(MID);

	// Get dimenstions.
	SEXP DIM1, DIM2;
	PROTECT(DIM1 = getAttrib(MID,R_DimSymbol));
	int NPROBES = INTEGER(DIM1)[0];
	PROTECT(DIM2 = getAttrib(KG_ID,R_DimSymbol));
	int NUMKG = INTEGER(DIM2)[0];

	// Return values.
	SEXP RETURN, gene_id, gene_dist;//, prb_ID;
	PROTECT(RETURN = allocVector(VECSXP, 2));
//	SET_VECTOR_ELT(RETURN, 0, prb_ID=allocVector(STRSXP, NPROBES));
	SET_VECTOR_ELT(RETURN, 0, gene_id=allocVector(STRSXP, NPROBES));
	SET_VECTOR_ELT(RETURN, 1, gene_dist=allocVector(INTSXP, NPROBES));
	int *GENE_DIST = INTEGER(gene_dist);

	int LOWEST_INDX, DIST, d;

	// Find the clostest gene.
	for(int prb=0;prb<NPROBES;prb++) {
		DIST = 990000000;

		/* Find the nearest gene! */
		for(int kg=0;kg<NUMKG;kg++) {
			// Calculates distance
			if(strcmp(CHAR(STRING_ELT(KG_STR, kg)), "+") == 0) {
				d = abs(gSTART[kg] - pMID[prb]);
			}
			else if(strcmp(CHAR(STRING_ELT(KG_STR, kg)), "-") == 0) {
				d = abs(gEND[kg] - pMID[prb]);
			}
			else {
				error("ERROR: Strand format should be '+', '-', but '%s' found.\n", 
					CHAR(STRING_ELT(KG_STR, kg)));
				UNPROTECT(3);
				return(R_NilValue);
			}

			if( d < DIST) {
				LOWEST_INDX = kg;
				DIST= d;
			}
		}

		/* Now!  Set the nearest gene! */
		SEXP KG_ID_dup;
		PROTECT(KG_ID_dup = duplicate(STRING_ELT(KG_ID, LOWEST_INDX)));
		SET_STRING_ELT(gene_id, prb, KG_ID_dup);
		UNPROTECT(1);
		GENE_DIST[prb] = DIST;
	}

	UNPROTECT(3);
	return(RETURN);
}

/*****************************************************************************************
*
*	Match a probeID to genes within a threshold distance.
*
*	Arguments:
*	KGID		<- String vector, the ID of known genes.
*	KGSTR		<- String vector, the strand (+/-) of known genes.
*	KGSTART		<- Integer vector, the start position (bp) of known genes.
*	KGEND		<- Integer vector, the end position (bp) of known genes.
*	PrbID		<- String vector, a unique ID for each probe to be assigned.
*	ProbeMID	<- Integer vector, the center position (bp) of each probe.
*	Dist 		<- Integer, the threshold for returning genes.
*
*	Return values: a matrix with the following components:
*	PRB_ID		<- String vector, probe ID.  
*	KG_ID		<- String vector, known gene ID.
*	KG_PRB_DIST	<- Integer vector, distance between the probe and gene.
*
*	Assumes:
*	All genes and probes are on the same chromosome!!
*	Arguments KGID, KGSTR, KGSTART, and KGEND have the same length.
*	Arugments PrbID, and ProbeMID have the same length.
*
*****************************************************************************************/
SEXP AssociateRegionWithGenesDI(SEXP KGID, SEXP KGSTR, SEXP KGSTART, SEXP KGEND, 
						SEXP PrbID, SEXP ProbeMID, SEXP Dist) {

	int *kgSTART  = INTEGER(KGSTART);
	int *kgEND    = INTEGER(KGEND);
	int *pMID       = INTEGER(ProbeMID);
	int D        = INTEGER(Dist)[0];

	// Get the dimensions.
	SEXP DIM1, DIM2;
	PROTECT(DIM1 = getAttrib(KGSTART,R_DimSymbol));
	int NKG = INTEGER(DIM1)[0];
	PROTECT(DIM2 = getAttrib(ProbeMID, R_DimSymbol));
	int NPROBES = INTEGER(DIM2)[0];

	// Count the number of hits... need to know before creating R-types.
	int NHITS=0, d;
	for(int prb=0;prb<NPROBES;prb++) {
		for(int kg=0;kg<NKG;kg++) {
			if(strcmp(CHAR(STRING_ELT(KGSTR, kg)), "+") == 0) {
				d = abs(kgSTART[kg] - pMID[prb]);
			}
			else if(strcmp(CHAR(STRING_ELT(KGSTR, kg)), "-") == 0) {
				d = abs(kgEND[kg] - pMID[prb]);
			}
			else {
				error("ERROR: Strand format should be '+', '-', but '%s' found.\n", 
					CHAR(STRING_ELT(KGSTR, kg)));
				UNPROTECT(2);
				return(R_NilValue);
			}

			if( d < D ) {
				NHITS++;
			}
		}
	}

	// Construct return values.
	SEXP RETURN, PRB_ID, KG_ID, KG_PRB_DIST;
	PROTECT(RETURN = allocVector(VECSXP, 3));
	SET_VECTOR_ELT(RETURN, 0,      PRB_ID=allocVector(STRSXP, NHITS));
	SET_VECTOR_ELT(RETURN, 1,       KG_ID=allocVector(STRSXP, NHITS));
	SET_VECTOR_ELT(RETURN, 2, KG_PRB_DIST=allocVector(INTSXP, NHITS));
	int *kg_p_D = INTEGER(KG_PRB_DIST);

	// the loop.
	int HITn=0;
	SEXP PRB_ID_Dup, KG_ID_Dup;
	for(int prb=0;prb<NPROBES;prb++) {
		for(int kg=0;kg<NKG;kg++) {
			// +/- strand?
			if(strcmp(CHAR(STRING_ELT(KGSTR, kg)), "+") == 0) {
				d= abs(kgSTART[kg] - pMID[prb]);
			}
			else {
				d= abs(kgEND[kg] - pMID[prb]);
			}

			// Do the assignment...
			if( d < D ) {
				PROTECT(PRB_ID_Dup = duplicate(STRING_ELT(PrbID, prb)));
				SET_STRING_ELT(PRB_ID, HITn, PRB_ID_Dup);

				PROTECT(KG_ID_Dup = duplicate(STRING_ELT(KGID, kg)));
				SET_STRING_ELT(KG_ID, HITn, KG_ID_Dup);
				UNPROTECT(2);

				kg_p_D[HITn] = d;

				HITn++;
			}
		}
	}

	UNPROTECT(3);
	return(RETURN);
}

/*****************************************************************************************
*
* Associates probes with genomic features -- or regions.
*
*	Arguments:
*	Feature_Start	-> integer vector representing the start of features along the chromosome.
*	Feature_End	-> integer vector representing the end of features along the chromosome.
*	ProbeStart	-> vector of integers that represents the start of each probe along the chromosome.
*	ProbeLength	-> vector of probe lengths
*
*	Returns:
*	integer array -- for each ProbeStart, the index of the feature that it is inside, or NA for none.
*
* 	Assumes:
*	The feature table passed as Feature_Start and Feature_End are on the same chromosome.
*	Feature_Start and Feature_End are of the same length.
*
*
*****************************************************************************************/
SEXP AssociateRegionWithFeatures(SEXP Feature_Start, SEXP Feature_End, SEXP ProbeStart, SEXP ProbeLength) {
	int *fSTART = INTEGER(Feature_Start);
	int *fEND = INTEGER(Feature_End);
	int *PS = INTEGER(ProbeStart);
	int *PL = INTEGER(ProbeLength);

	// Get the dimensions.
	SEXP DIM1, DIM2;
	PROTECT(DIM1 = getAttrib(Feature_Start,R_DimSymbol));
	int NCPG = INTEGER(DIM1)[0];
	PROTECT(DIM2 = getAttrib(ProbeStart, R_DimSymbol));
	int NPROBES = INTEGER(DIM2)[0];

	// Construct return values.
	SEXP fID;
	PROTECT(fID = allocVector(INTSXP,NPROBES));
	int *fcID = INTEGER(fID);

	// Assign probes to a feature
	for(int prb=0;prb<NPROBES;prb++) {
		fcID[prb] = NCPG+1; // This will add NA when names are added in R.
		for(int i=0;i<NCPG;i++) {
			if((fSTART[i] < (PS[prb] + PL[prb])) && (fEND[i] > PS[prb])) {
				fcID[prb] = (i+1);
				break; // Only 1 feature for each probe!
			}
		}
	}

	UNPROTECT(3);
	return(fID);
}


/*****************************************************************************************
*
* Extracts RAW intensities from a VECTOR taken directly from a CEL file.
*
*	Arguments:
*	X	<- Integer vector, X position of the probe in CEL.
*	Y	<- Integer vector, Y position of the probe in CEL.
*	INT	<- Real vector, RAW intensities read from the CEL file.
*	COLSIZE	<- Integer, number of intensities in a column of the CEL file.
*
*	Returns: 
*	Real vector, sorted intensities.
*
*****************************************************************************************/
SEXP ExtractRAWIntensity(SEXP X, SEXP Y, SEXP INT, SEXP COLSIZE) {
	int *x = INTEGER(X);
	int *y = INTEGER(Y);
	double *I = REAL(INT);
	int cs = INTEGER(COLSIZE)[0];

	SEXP /*dimi,*/ dimxy;
/*	PROTECT(dimi = getAttrib(INT,R_DimSymbol));
	int DIM_I = INTEGER(dimi)[0];*/
	PROTECT(dimxy = getAttrib(X, R_DimSymbol));
	int DIM_xy = INTEGER(dimxy)[0];

	SEXP SI;
	PROTECT(SI = allocVector(REALSXP,DIM_xy));
	double *si = REAL(SI);

	for(int i=0;i<DIM_xy;i++) {
		si[i] = I[(y[i]) * cs + (x[i])]; // 08-03-17
	}

	UNPROTECT(2);
	return(SI);
}

SEXP R_affx_parseBPMAP(SEXP fname, 

				SEXP seqindices, 
				SEXP limitToInterval,
				SEXP iID,
				SEXP iCHR,
				SEXP iSTART,
				SEXP iEND,

				SEXP makeUniqueID,
				SEXP readOnlyNCBI,
				SEXP readProbeSeq,
				SEXP verbose);

/**************************************************************
*
*	Register entry points...
*
**************************************************************/
void R_init_AffyTiling(DllInfo *info) {
     R_CallMethodDef callMethods[]  = {
       {"AssociateRegionWithGenes", (DL_FUNC)&AssociateRegionWithGenes, 5},
       {"AssociateRegionWithGenesDI", (DL_FUNC)&AssociateRegionWithGenesDI, 7},
       {"AssociateRegionWithFeatures", (DL_FUNC)&AssociateRegionWithFeatures, 4},
       {"ExtractRAWIntensity", (DL_FUNC)&ExtractRAWIntensity, 4},
       {"R_affx_parseBPMAP", (DL_FUNC)&R_affx_parseBPMAP, 12},
       {NULL, NULL, 0}
     };

	R_registerRoutines(info, NULL, callMethods, NULL, NULL);
}

}
