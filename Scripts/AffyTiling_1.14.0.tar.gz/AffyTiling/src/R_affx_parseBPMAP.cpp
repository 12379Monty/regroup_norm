/********************************************************************************
 *
 *	Source for R_affx_parseBPMAP() based on affxparser 1.10.2, by James Bullard and Kasper Daniel Hansen.
 *
 *	Modified 2008-03-02 by Charles Danko.
 *	Modified copy passed known gene/ intevral of interest information.  Returns
 *	probes in these regions.
 *
 *	2008-03-09 Forcing users to skip TIGR coordinates ... 
 *	--including them may provide more confusion than utility, since most users 
 *	  will be working in NCBI coordinates.
 *
 *	2008-07-07 Updated code to be more readable -- Improved comments + "DO NOT REPEAT" compliance.
 *
 *	2008-11-13 Now linking to functions in affxparser directly using C function pointers.
 *
 *	2009-10-6 No longer skips TIGR coordinates (causes problems with Arabidopsis).  
 *			To distingusih NCBY & TIGR coordniates, returns full name.
 *
 *******************************************************************************/

#include "BPMAPFileData.h"
#include "BPMAPFileWriter.h"
#include "R_affx_constants.h"

using namespace std;

extern "C" {
    #include <iostream>
    #include <string>
    #include <R.h>
    #include <S.h>
    #include <Rdefines.h>
    #include <wchar.h>
    #include <wctype.h>


/*****************************************************************************************
*
*	AssociatewithInterval -- Pass the index at which to start looking ...
*	To prevent copying of a large table, pass values by reference.
*
*	Not intended for public consumption -- not included in AffyTiling namespace.
*
*	Arguments:
*	fCHR		<- String vector, the chromosome of features.
*	fSTART		<- Integer vector, the start position of features.
*	fEND		<- Integer vector, the end position of features.
*	nFeatures	<- C int, the number of features (i.e. the length of fCHR, fSTART, and fEND).
*	ProbeChr	<- C char, the strand of the probe to test.
*	ProbeStart	<- C int, the start position of the probe.
*	prbSize		<- C int, the size of the probe.
*	CountStart	<- C int, starts the loop at this number -- optomization.
*
*	Returns: 
*	The index of the feature that a probe rests inside, or -1 for probes not inside any feature.
*
*	Assumes that both chromosomes AND probes are presented in the SAME ORDER IN THE BPMAP and TABLE!
*	XXX	TODO: Implement a wrap-around feature that limits exceptions.
*	XXX	TODO: Implement further optomizations: ... pass the correct chromosome?  BREAK :)
*	XXX	TODO: Stop running after numbers are greater on same CHR.
*		TODO: How quick is the STRING_ELT function??  Try converting all of these to C variables...
*
*****************************************************************************************/

int AssociateWithInterval(SEXP fCHR, SEXP f_START, SEXP f_END, int nFeatures, 
				char* ProbeChr, int ProbeStart, int prbSize, int CountStart) {
	int *fSTART = INTEGER(f_START);
	int *fEND = INTEGER(f_END);
	bool hit_correct_CHR = FALSE;
	bool loop_around_once = FALSE;

// Start 1 position back...
	if(CountStart > 0)
		CountStart--;

	looping:
	for(int i=CountStart;i<nFeatures;i++) {
		if( strcmp(CHAR(STRING_ELT(fCHR, i)), ProbeChr) == 0 ) {
			if((fSTART[i] < (ProbeStart + prbSize)) && (fEND[i] > ProbeStart)) {
				return(i);
			}
//			else if(ProbeStart > fEND[i]) { // It is the correct CHR, but numbers have passed.
//				return(-1);
//			} // This was killing most of the hits ... why?
			hit_correct_CHR = TRUE;
		}
		else {
			if(hit_correct_CHR) // We are already done with the correct CHR :)
				return(-1);
		}
	}
	
	// Wrap around ... just in case probes are not in the same order.
	if(!loop_around_once) {
		nFeatures=CountStart; CountStart=0;
		loop_around_once = TRUE;
		goto looping;
	}

	return(-1);
}


/*****************************************************************************************
*
*	R_affx_parseBPMAP -- Parse the bpmap file ...
*
*	Arguments:
*	fname		  <- String, the filename of the BPMAP file.
*	seqindices	  <- Integer vector, the index of the chromosomes to read (same as in affxparser package).
*	limitToInterval   <- Logical, limits the returned table to probes in one of the intervals specified 
*			     by the vectors: iID, iCHR, iSTART, iEND (see below)
*	recordIntervalIDs <- Logical, returns the iID of interval for each probe.  Presently, requires limitToInterval.
*	iID		  <- String vector, a uniqueID for each feature.
*	iCHR		  <- String vector, the chromosome of features.
*	iSTART		  <- Integer vector, the start position of features.
*	iEND		  <- Integer vector, the end position of features.
*	makeUniqueID	  <- Logical, returns a unique ID for each probe.
*	readOnlyNCBI      <- Logical, reads ONLY chromosomes with NCBI in the name.
*	readProbeSeq	  <- Logical, returns the sequence for each probe.
*	verbose		  <- Logical, output debug information to the standard output.
*
*	Returns: 
*	Matrix of probes and the corresponding X and Y position in the CEL file.  Exact format of the
*	output matrix depends on logical arguments, enumerated above.
*
*
*****************************************************************************************/
SEXP R_affx_parseBPMAP(SEXP fname, 

				SEXP seqindices, 
				SEXP limitToInterval,
				SEXP recordIntervalIDs,
				SEXP iID,
				SEXP iCHR,
				SEXP iSTART,
				SEXP iEND,

				SEXP makeUniqueID,
				SEXP readOnlyNCBI,
				SEXP readProbeSeq,
				SEXP verbose) 
    {

	/* constants */
        const int sizeCHR=50, sizeSEQ=25;

        /* Process arguments */
	int i_readOnlyNCBI      = INTEGER(readOnlyNCBI)[0];
        int i_readProbeSeq      = INTEGER(readProbeSeq)[0];
        int i_verboseFlag       = INTEGER(verbose)[0];
	int i_limitInterval     = INTEGER(limitToInterval)[0];
	int i_makeUniqueID      = INTEGER(makeUniqueID)[0];
	int i_recordIntervalIDs = INTEGER(recordIntervalIDs)[0];

        /* Opens the BPMAP file */
        const char* bpmapFileName   = CHAR(STRING_ELT(fname,0));
        affxbpmap::CBPMAPFileData bpmap;
        if (i_verboseFlag >= R_AFFX_VERBOSE) {
            Rprintf("attempting to read: %s\n", bpmapFileName);
        }
        bpmap.SetFileName(bpmapFileName);

        if (bpmap.Exists() == false) {
            error("File does not exist: %s.\nPlease specify a valid .bpmap file.", bpmapFileName);
            return R_NilValue;
        }
        if (bpmap.Read() == false) {
            error("Unable to read file: %s, is it a BPMAP file?\n", bpmapFileName);
            return R_NilValue;
        }
        if (i_verboseFlag >= R_AFFX_VERBOSE) {
            Rprintf("sucessfully read: %s\n", bpmapFileName);
        }

	/* Includes from the affy SDK */
        affxbpmap::CGDACSequenceItem seq;
        affxbpmap::GDACSequenceHitItemType seqHit;

	/* Get the number of intervals that were passed... */
	int nFeatures;
	if(i_limitInterval) {
		SEXP DIM;
		PROTECT(DIM = getAttrib(iID,R_DimSymbol));
		nFeatures = INTEGER(DIM)[0];
		UNPROTECT(1);
	}

        /* checking whether or not we are reading everything or just
         * some of the sequences. We assume that R delivers the 
         * indices in a sorted way */
        int nSequences = bpmap.GetNumberSequences();
        int nSequenceIndices = length(seqindices);
        bool readAllSequences = false;
        if(nSequenceIndices == 0) {
            readAllSequences = true;
        } else {
            /* and some error checking of the argument */
            for(int i = 0; i < nSequenceIndices; i++) {
                if(INTEGER(seqindices)[i] < 0 | INTEGER(seqindices)[i] > nSequences)
                    error("seqIndices out of range");
            }
            nSequences = nSequenceIndices;
        }

	/* Added 3-3-08 --> Calculate how many probes we are reading... this dosen't take very long. */
	int NPROBES = 0;
        for(int i = 0; i < nSequences; i++)
        {
		/* Load sequence hits using Affymetrix SDK */
                if(readAllSequences) {
                    bpmap.GetSequenceItem(i, seq);
                } else {
                    bpmap.GetSequenceItem(INTEGER(seqindices)[i] - 1, seq); //Fusion indices are zero base
                } 

		// Check for NCBI coordinates -- makes room for AFFY controls, but ALWAYS skips TIGR!
//		if( strncmp(seq.GroupName().c_str(), "At", 2) == 0 )
//			continue; // Force skip TIGR coordinates ...

		if( i_readOnlyNCBI && (strncmp(seq.GetSeqVersion().c_str(), "NCBI", 4) != 0) )
			continue; // Don't count non NCBI...

                NPROBES += seq.GetNumberHits(); // Can we limit regions by genomic position??
	}

	// Store data in struct of C variables.
	struct bpmap_data_c {
		int iIDindx;
		int start;
		int pmx;
		int pmy;
	
		char chr[sizeCHR+1];
		char sequence[sizeSEQ+1]; // Make this variable, and dependent on array ...
	} *bd;
	bd = (bpmap_data_c*)Salloc(NPROBES, bpmap_data_c);

        /* Read the sequences. */
	NPROBES = 0;
        for(int i = 0; i < nSequences; i++)
        {
		/* Check that we are reading the current chromosome (or sequence) */
                if(readAllSequences) {
                    bpmap.GetSequenceItem(i, seq);
                } else {
                    /* Fusion indices are zero base */
                    bpmap.GetSequenceItem(INTEGER(seqindices)[i] - 1, seq);
                }

//		if( (strncmp(seq.GroupName().c_str(), "At", 2) == 0) )
//			continue;

		if( i_readOnlyNCBI && (strncmp(seq.GetSeqVersion().c_str(), "NCBI", 4) != 0) )
			continue;

                if (i_verboseFlag >= R_AFFX_VERBOSE) {
			Rprintf("Reading sequence object: %s\n", seq.FullName().c_str());
			Rprintf("GroupName: %s\n", seq.GroupName().c_str());
			Rprintf("FullName:  %s\n", seq.FullName().c_str());
			Rprintf("SeqVer:    %s\n", seq.GetSeqVersion().c_str());
                }

		/* Record all hits from each CHR (or Sequence in the termonology that seems to be used here.) */
		int nHits = seq.GetNumberHits();
//		int TotalProbesNOTInINTERVAL = 0;
		int OldCounter=0, NewCounter=0, TMPStart=0;
                for(int j = 0; j < nHits; j++) {
			if(j % 1000 == 999)
				R_CheckUserInterrupt();

                        seq.GetHitItem(j, seqHit, i_readProbeSeq); /* Get next hit! */

			/* Does this hit fall in the interval ?? */
			TMPStart = seqHit.getStartPosition();
			if(i_limitInterval) {
				NewCounter = AssociateWithInterval(iCHR, iSTART, iEND, nFeatures, 
					(char*)seq.FullName().c_str(), TMPStart, seqHit.ProbeLength, OldCounter);
				if(NewCounter == -1) {
//					TotalProbesNOTInINTERVAL++; // For resizing after the CHR.
					continue; // Just move on...
				}
				else {
					OldCounter = NewCounter;
				}
			}

			/* Assignments */
			bd[NPROBES].start = TMPStart;
			bd[NPROBES].pmx = seqHit.PMX;
			bd[NPROBES].pmy = seqHit.PMY;
			snprintf(bd[NPROBES].chr, sizeCHR+1, "%s\0", (char*)seq.FullName().c_str());
                        if (i_readProbeSeq)
				snprintf(bd[NPROBES].sequence, sizeSEQ+1, "%s\0", seqHit.PMProbe.c_str());
			if (i_recordIntervalIDs && i_limitInterval)
				bd[NPROBES].iIDindx = OldCounter;

			NPROBES++; /* Added 3-3-08 */
		}

                /* Resize the large struct ... knock off TotalProbesNOTInINTERVAL */
//		bd = (bpmap_data_c*)Srealloc(bd, (sizeof(bd) - sizeof(bpmap_data_c)*TotalProbesNOTInINTERVAL));
//		bd = (bpmap_data_c*)realloc(bd, (sizeof(bd) - sizeof(bpmap_data_c)*TotalProbesNOTInINTERVAL));
            }

    /* Return stuff */
        if (i_verboseFlag >= R_AFFX_REALLY_VERBOSE) {
            Rprintf("Finalizing BPMAP object\n");
        }
        bpmap.Close();

	/* Cretae return matrix. */
	int nReturn = 4;
	if(i_readProbeSeq) { // Process conditionals...
		nReturn++;
	}
	if (i_recordIntervalIDs && i_limitInterval) {
		nReturn++;
	}
	if(i_makeUniqueID) {
		nReturn++;
	}

	SEXP SmallMatrix, UniqueID, CHR, Start, SEQ, PMX, PMY, iIDvec, COL_Names;
	PROTECT(SmallMatrix = allocVector(VECSXP, nReturn));
        PROTECT(COL_Names = NEW_CHARACTER(nReturn));

	int RN = 0;
	if(i_makeUniqueID) { 
		SET_VECTOR_ELT(SmallMatrix, RN, UniqueID=allocVector(STRSXP, NPROBES));
		SET_STRING_ELT(COL_Names, RN++, mkChar("UniqueID"));
	}

	SET_VECTOR_ELT(SmallMatrix, RN, CHR=allocVector(STRSXP, NPROBES));
	SET_STRING_ELT(COL_Names, RN++, mkChar("CHR"));

	SET_VECTOR_ELT(SmallMatrix, RN, Start=allocVector(INTSXP, NPROBES));
	SET_STRING_ELT(COL_Names, RN++, mkChar("Start"));

	SET_VECTOR_ELT(SmallMatrix, RN, PMX=allocVector(INTSXP, NPROBES));
	SET_STRING_ELT(COL_Names, RN++, mkChar("PMX"));

	SET_VECTOR_ELT(SmallMatrix, RN, PMY=allocVector(INTSXP, NPROBES));
	SET_STRING_ELT(COL_Names, RN++, mkChar("PMY"));

	if(i_readProbeSeq) {
		SET_VECTOR_ELT(SmallMatrix, RN, SEQ=allocVector(STRSXP, NPROBES));
		SET_STRING_ELT(COL_Names, RN++, mkChar("SEQ"));
	}

	if (i_recordIntervalIDs && i_limitInterval) {
		SET_VECTOR_ELT(SmallMatrix, RN, iIDvec=allocVector(STRSXP, NPROBES));
		SET_STRING_ELT(COL_Names, RN++, mkChar("iID"));
	}

	/* Write colnames to SmallMatrix */
        setAttrib(SmallMatrix, R_NamesSymbol, COL_Names);

	/* Run through assigning values to SmallMatrix. */
	if (i_verboseFlag >= R_AFFX_VERBOSE)
		Rprintf("Making return list\n");

	for(int i=0;i<NPROBES;i++) {
		if(i_makeUniqueID) {
			char *TMP = (char*)Calloc((sizeCHR+20), char);
			sprintf(TMP, "%s-%i\0", bd[i].chr, bd[i].start);
			SET_STRING_ELT(UniqueID, i, mkChar(TMP));
			Free(TMP);  // 3-29-08 Changed from Calloc to Salloc
		}
		SET_STRING_ELT(CHR, i, mkChar(bd[i].chr));  /* Added 3-3-08 */
		INTEGER(Start)[i] = bd[i].start; /* Added 3-3-08 */
		INTEGER(PMX)[i] = bd[i].pmx; /* Added 3-3-08 */
		INTEGER(PMY)[i] = bd[i].pmy; /* Added 3-3-08 */
		if (i_readProbeSeq)
			SET_STRING_ELT(SEQ, i, mkChar(bd[i].sequence));
		if (i_recordIntervalIDs && i_limitInterval) {
			SEXP i_ID_Dup; // Temporary pointer, R doesn't allow assignment of one address to multiple vars.
			PROTECT(i_ID_Dup = duplicate(STRING_ELT(iID, bd[i].iIDindx)));
			SET_STRING_ELT(iIDvec, i, i_ID_Dup);
			UNPROTECT(1);
		}
	}

        UNPROTECT(2);
	return SmallMatrix;
    }/* R_affx_parseBPMAP() */


} /** end extern "C" **/

